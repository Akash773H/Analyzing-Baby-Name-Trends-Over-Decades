-- Count the total number of births by gender for each state.
SELECT 
    r.state, SUM(n.births) AS no_of_births
FROM
    names n
        JOIN
    regions r ON n.state = r.state
GROUP BY r.state
ORDER BY r.state;

-- Find the total number of births for each name in a particular state
SELECT 
    n.name, SUM(n.births) AS no_of_births
FROM
    names n
        JOIN
    regions r ON n.state = r.state
WHERE
    r.state = 'CA'
GROUP BY n.name , r.state
ORDER BY n.name;

-- List all names along with the total number of births in the year 2000
SELECT 
    name, SUM(births) AS no_of_births
FROM
    names
WHERE
    year = 2000
GROUP BY name , year
ORDER BY name;

-- Find the top 5 most popular names in the year 1990
SELECT 
    name, SUM(births) AS no_of_births
FROM
    names
WHERE
    year = 1990
GROUP BY name , year
ORDER BY no_of_births DESC
LIMIT 5;

-- Display the total number of births for each region in the year 2005
SELECT 
    r.state, SUM(births) AS no_of_births
FROM
    names n
        JOIN
    regions r ON n.state = r.state
WHERE
    n.year = 2005
GROUP BY r.state , n.year
ORDER BY r.state;

-- Find the top 3 names for each gender in the year 2000 across all states
SELECT name, gender, no_of_births
FROM
	(SELECT
		name,
        gender,
        SUM(births) AS no_of_births,
        RANK() OVER(PARTITION BY gender ORDER BY SUM(births) DESC) AS rn
	FROM 
		names
	WHERE 
		year = 2000
	GROUP BY name, gender, year) as temp_a
WHERE 
	rn < 4;

-- Identify the state with the highest total number of births between 1995 and 2005
SELECT 
    r.state, SUM(births) AS no_of_births
FROM
    names n
        JOIN
    regions r ON n.state = r.state
WHERE
    n.year BETWEEN 1995 AND 2005
GROUP BY r.state
ORDER BY no_of_births DESC
LIMIT 1;

-- Show the names that were popular in at least 3 different states in any single year
SELECT 
    name, year, COUNT(DISTINCT state) AS state_count
FROM
    names
GROUP BY name , year
HAVING state_count >= 3
ORDER BY year , state_count DESC;

-- Calculate the percentage of births in each state for a given year (e.g., 2000) relative to the total births across all states
SELECT 
    r.state,
    ROUND((SUM(n.births) / (SELECT 
                    SUM(births)
                FROM
                    names
                WHERE
                    year = 2000)) * 100,
            1) AS relative_percentage_of_births
FROM
    names n
        JOIN
    regions r ON n.state = r.state
WHERE
    year = 2000
GROUP BY r.state
ORDER BY relative_percentage_of_births DESC;

-- Find the average number of births per year for each name that starts with 'A'
SELECT 
    year, ROUND(AVG(births), 2) AS avg_no_of_births
FROM
    names
WHERE
    name LIKE 'a%';

-- Identify the top 3 most popular names for each state in the last 5 years of the dataset (2000–2005)
SELECT
	name, state, no_of_births
FROM
(SELECT
	n.name,
    r.state,
    SUM(n.births) AS no_of_births,
	RANK() OVER(PARTITION BY r.state ORDER BY SUM(n.births) DESC) AS rn
FROM
    names n
        JOIN
    regions r ON n.state = r.state
WHERE
    n.year BETWEEN 2000 AND 2005
    GROUP BY n.name, r.state) AS temp_a
    WHERE rn < 4;
    
-- For each region, find the names that have been consistently in the top 10 for every year between 1990 and 2000
SELECT region, name
FROM(
	SELECT 
		r.region, n.name, n.year, SUM(n.births) AS no_of_births,
		rank() over(partition by r.region, n.year order by SUM(n.births) desc) as rn
	FROM
		names n
			JOIN
		regions r ON n.state = r.state
	WHERE
		n.year BETWEEN 1990 AND 2000
	GROUP BY r.region , n.name , n.year) as a
where rn < 11
group by region, name;

-- Identify which names were given to both boys and girls,
-- and find out if there’s a trend where they became more common for one gender between 2000-2005
WITH bothgenders AS(
	SELECT 
		name
	FROM
		names
	GROUP BY name
	HAVING COUNT(DISTINCT gender) = 2
),
totalbirths AS(
	SELECT 
		year, SUM(births) as total_births
	FROM
		names
	GROUP BY year
)
SELECT
	n.name,
    n.gender,
    n.year,
    SUM(births) as no_of_births,
    (SUM(births)/tb.total_births)*100 as birth_percentage
FROM names n
JOIN bothgenders bg ON n.name = bg.name
JOIN totalbirths tb ON n.year = tb.year
WHERE n.year BETWEEN 2000 AND 2005
GROUP BY n.name, n.gender, n.year
ORDER BY n.name, n.year;

-- Find names that appeared in one state but not in another state during the same year
SELECT DISTINCT
    n1.name, n1.state, n1.year
FROM
    names n1
WHERE
    (n1.name , n1.year) NOT IN (SELECT 
            n2.name, n2.year
        FROM
            names n2
        WHERE
            n1.state <> n2.state)
ORDER BY n1.year , n1.state , n1.name;

-- What were the most popular baby names of each decade?
-- Solution 1
WITH rank_names AS(
	SELECT
		name,
		FLOOR(year / 10) * 10 AS decade,
		SUM(births) AS no_of_births,
		RANK() OVER(PARTITION BY FLOOR(year / 10) * 10 ORDER BY SUM(births) DESC) AS rn
	FROM names
	GROUP BY name, decade
)
SELECT name, decade, no_of_births
FROM rank_names
WHERE rn = 1;
-- Solution 2
SELECT name, decade, total_births
FROM (
    SELECT 
        name,
        FLOOR(year / 10) * 10 AS decade,
        SUM(births) AS total_births,
        RANK() OVER (PARTITION BY FLOOR(year / 10) * 10 ORDER BY SUM(births) DESC) AS rn
    FROM names
    GROUP BY name, decade
) AS RankedNamesByDecade
WHERE rn = 1;

-- Which baby names had the biggest jumps and drops in popularity?
SELECT 
    name,
    SUM(CASE
        WHEN year BETWEEN 1980 AND 1989 THEN births
        ELSE 0
    END) AS 80s,
    SUM(CASE
        WHEN year BETWEEN 1990 AND 1999 THEN births
        ELSE 0
    END) AS 90s,
    SUM(CASE
        WHEN year BETWEEN 2000 AND 2009 THEN births
        ELSE 0
    END) AS 00s,
    (SUM(CASE
        WHEN year BETWEEN 1990 AND 1999 THEN births
        ELSE 0
    END) - SUM(CASE
        WHEN year BETWEEN 1980 AND 1989 THEN births
        ELSE 0
    END)) AS jumps_between_80s_and_90s,
    (SUM(CASE
        WHEN year BETWEEN 2000 AND 2009 THEN births
        ELSE 0
    END) - SUM(CASE
        WHEN year BETWEEN 1990 AND 1999 THEN births
        ELSE 0
    END)) AS jumps_between_90s_and_00s
FROM
    names
GROUP BY name
HAVING jumps_between_80s_and_90s IS NOT NULL
    OR jumps_between_90s_and_00s IS NOT NULL
ORDER BY jumps_between_80s_and_90s DESC, jumps_between_90s_and_00s ASC;